import java.util.ArrayList;
import java.util.List;

class Book 
{
    private String id;
    private String title;
    private String author;
    private int copiesAvailable;

    public Book(String id, String title, String author, int copiesAvailable) 
    {
        this.id = id;
        this.title = title;
        this.author = author;
        this.copiesAvailable = copiesAvailable;
    }

    public String getId() 
    {
        return id;
    }

    public String getTitle() 
    {
        return title;
    }

    public String getAuthor() 
    {
        return author;
    }

    public int getCopiesAvailable() 
    {
        return copiesAvailable;
    }

    
    public String toString() 
    {
        return "Book{id='" + id + "', title='" + title + "', author='" + author + "', copiesAvailable=" + copiesAvailable + "}";
    }
}

public class Library 
{
    private List<Book> books;

    public Library() 
    {
        this.books = new ArrayList<>();
    }

    
    public void addBook(Book book) 
    {
        books.add(book);
    }

    
    public boolean removeBook(String id) 
    {
        for (Book book : books) 
        {
            if (book.getId().equals(id)) 
            {
                books.remove(book);
                return true;
            }
        }
        return false;
    }

    
    public List<Book> findBooksByAuthor(String author) 
    {
        List<Book> result = new ArrayList<>();
        for (Book book : books) 
        {
            if (book.getAuthor().equalsIgnoreCase(author)) 
            {
                result.add(book);
            }
        }
        return result;
    }

    
    public List<Book> findBooksWithFewerCopies(int copies) 
    {
        List<Book> result = new ArrayList<>();
        for (Book book : books) 
        {
            if (book.getCopiesAvailable() < copies) 
            {
                result.add(book);
            }
        }
        return result;
    }

    public static void main(String[] args) 
    {
        Library library = new Library();
        
        library.addBook(new Book("101", "Big Data", "Author A", 5));
        library.addBook(new Book("102", "Machine Learning", "Author B", 3));
        library.addBook(new Book("103", "Python", "Author A", 2));
        library.addBook(new Book("104", "Java", "Author E", 1));
        library.addBook(new Book("105", "Linux", "Author C", 7));
        library.addBook(new Book("106", "DBMS", "Author D", 4));
        library.addBook(new Book("107", "Statistics", "Author B", 6));
        library.addBook(new Book("108", "Data Vizualisation", "Author E", 1	));
       
        library.removeBook("104");
        
        List<Book> booksByAuthorA = library.findBooksByAuthor("Author A");
        System.out.println("Books by Author A:");
        for (Book book : booksByAuthorA) 
        {
            System.out.println(book);
        }       
        List<Book> booksWithFewerCopies = library.findBooksWithFewerCopies(3);
        System.out.println("Books with fewer than 3 copies available:");
        for (Book book : booksWithFewerCopies) 
        {
            System.out.println(book);
        }
    }
}
