import java.util.HashMap;
import java.util.Map;


class ItemNotFoundException extends Exception 
{
    public ItemNotFoundException(String message) 
    {
        super(message);
    }
}

class InsufficientStockException extends Exception 
{
    public InsufficientStockException(String message) 
    {
        super(message);
    }
}


class InvalidQuantityException extends Exception 
{
    public InvalidQuantityException(String message) 
    {
        super(message);
    }
}

class Inventory 
{
    private Map<String, Integer> items;

    public Inventory() 
    {
        this.items = new HashMap<>();
    }

    public void addItem(String itemName, int quantity) throws InvalidQuantityException 
    {
        if (quantity <= 0) 
        {
            throw new InvalidQuantityException("Quantity must be greater than zero.");
        }
        items.put(itemName, items.getOrDefault(itemName, 0) + quantity);
    }

    public void removeItem(String itemName, int quantity) throws ItemNotFoundException, InsufficientStockException, InvalidQuantityException 
    {
        if (quantity <= 0) 
        {
            throw new InvalidQuantityException("Quantity must be greater than zero.");
        }
        if (!items.containsKey(itemName)) 
        {
            throw new ItemNotFoundException("Item not found: " + itemName);
        }
        if (items.get(itemName) < quantity) 
        {
            throw new InsufficientStockException("Insufficient stock for item: " + itemName);
        }
        items.put(itemName, items.get(itemName) - quantity);
    }

    public int getStock(String itemName) throws ItemNotFoundException 
    {
        if (!items.containsKey(itemName)) 
        {
            throw new ItemNotFoundException("Item not found: " + itemName);
        }
        return items.get(itemName);
    }

    public static void main(String[] args) 
    {
        Inventory inventory = new Inventory();

        try 
        {
            inventory.addItem("Laptop", 10);
            inventory.addItem("Mouse", 20);

            System.out.println("Laptop stock: " + inventory.getStock("Laptop"));
            System.out.println("Mouse stock: " + inventory.getStock("Mouse"));

            inventory.removeItem("Laptop", 5);
            System.out.println("Laptop stock after removal: " + inventory.getStock("Laptop"));

            inventory.removeItem("Keyboard", 1); 
        } catch (ItemNotFoundException | InsufficientStockException | InvalidQuantityException e) 
        {
            System.err.println(e.getMessage());
        }

        try 
        {
            inventory.removeItem("Mouse", 25); 
        } catch (ItemNotFoundException | InsufficientStockException | InvalidQuantityException e) 
        {
            System.err.println(e.getMessage());
        }

        try 
        {
            inventory.addItem("Monitor", -5); 
        } catch (InvalidQuantityException e) 
        {
            System.err.println(e.getMessage());
        }
    }
}




