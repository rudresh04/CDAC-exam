class Person
{
	String Name;
	int Age;
		
	public Person(String name, int age) 
	{
		super();
		Name = name;
		Age = age;
	}
	public String getName() 
	{
		return Name;
	}
	public void setName(String name) 
	{
		Name = name;
	}
	public int getAge() 
	{
		return Age;
	}
	public void setAge(int age) 
	{
		Age = age;
	}	
}

class Patient extends Person 
{
	int PatientId;
	String Aailment;
	
	public Patient(String name, int age, int patientId, String aailment) 
	{
		super(name, age);
		PatientId = patientId;
		Aailment = aailment;
	}
	public Patient(String name, int age) 
	{
		super(name, age);
	}	
}

public class ConstructChain
{
	public static void main(String[] args) {
		Patient  mypatient = new Patient("Rudresh",22,1001,"Typhoid");
		
		System.out.println("----Patient Details----");
		System.out.println("Name       :- " + mypatient.Name);
		System.out.println("Age        :- " + mypatient.Age);
		System.out.println("Patient Id :- " + mypatient.PatientId);
		System.out.println("Disease    :- " + mypatient.Aailment);		
	}
}